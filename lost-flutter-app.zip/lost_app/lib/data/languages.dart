class Lang {
  final String name;
  final String text;
  final bool rtl;
  const Lang(this.name, this.text, {this.rtl = false});
}

// TODO: проверить переводы с носителями языков.
const kLangs = <Lang>[
  Lang('Русский', 'Вы потеряли что-то?'),
  Lang('English', 'Did you lose something?'),
  Lang('中文', '您丢了东西吗？'),
  Lang('हिन्दी', 'क्या आपने कुछ खोया है?'),
  Lang('Español', '¿Has perdido algo?'),
  Lang('العربية', 'هل فقدت شيئًا؟', rtl: true),
  Lang('Français', 'Vous avez perdu quelque chose ?'),
  Lang('বাংলা', 'আপনি কি কিছু হারিয়েছেন?'),
  Lang('Português', 'Perdeu alguma coisa?'),
  Lang('اردو', 'کیا آپ نے کچھ کھو دیا ہے؟', rtl: true),
  Lang('Indonesia', 'Apakah Anda kehilangan sesuatu?'),
  Lang('Deutsch', 'Haben Sie etwas verloren?'),
  Lang('日本語', '何か失くしましたか？'),
  Lang('Türkçe', 'Bir şey mi kaybettiniz?'),
  Lang('한국어', '무언가 잃어버리셨나요?'),
  Lang('Italiano', 'Hai perso qualcosa?'),
];
