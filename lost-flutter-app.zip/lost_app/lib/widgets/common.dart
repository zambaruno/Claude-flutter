import 'dart:io';
import 'package:flutter/material.dart';
import '../theme.dart';

class AccentButton extends StatelessWidget {
  final IconData icon;
  final String label; // для скринридеров, на экране не показывается
  final VoidCallback? onPressed;
  final double height;
  final double iconSize;
  const AccentButton({super.key, required this.icon, required this.label, this.onPressed, this.height = 56, this.iconSize = 30});

  @override
  Widget build(BuildContext context) => Semantics(
        button: true,
        label: label,
        child: SizedBox(
          height: height,
          width: double.infinity,
          child: ElevatedButton(
            onPressed: onPressed,
            style: ElevatedButton.styleFrom(
              backgroundColor: C.accent,
              foregroundColor: C.ink,
              disabledBackgroundColor: C.line,
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: Icon(icon, size: iconSize),
          ),
        ),
      );
}

class OutlineIconButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onPressed;
  final double size;
  final double iconSize;
  const OutlineIconButton({super.key, required this.icon, required this.label, this.onPressed, this.size = 44, this.iconSize = 22});

  @override
  Widget build(BuildContext context) => Semantics(
        button: true,
        label: label,
        child: SizedBox(
          width: size,
          height: size,
          child: OutlinedButton(
            onPressed: onPressed,
            style: OutlinedButton.styleFrom(
              padding: EdgeInsets.zero,
              foregroundColor: C.accent,
              side: const BorderSide(color: C.line, width: 2),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: Icon(icon, size: iconSize),
          ),
        ),
      );
}

/// Широкая кнопка с одной пиктограммой (вход, донаты).
class WideButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onPressed;
  final Color? background; // null = контурная
  final Color foreground;
  const WideButton({super.key, required this.icon, required this.label, this.onPressed, this.background, this.foreground = C.accent});

  @override
  Widget build(BuildContext context) => Semantics(
        button: true,
        label: label,
        child: SizedBox(
          height: 64,
          width: double.infinity,
          child: ElevatedButton(
            onPressed: onPressed,
            style: ElevatedButton.styleFrom(
              backgroundColor: background ?? Colors.transparent,
              foregroundColor: foreground,
              elevation: 0,
              side: background == null ? const BorderSide(color: C.line, width: 2) : null,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: Icon(icon, size: 30),
          ),
        ),
      );
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = C.line..strokeWidth = 1;
    for (double x = 0; x < size.width; x += 24) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += 24) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

/// Мини-карта с меткой. TODO: заменить на настоящую карту.
class MiniMap extends StatelessWidget {
  final double height;
  const MiniMap({super.key, this.height = 56});

  @override
  Widget build(BuildContext context) => Semantics(
        label: 'Место находки',
        child: Container(
          height: height,
          decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(12)),
          clipBehavior: Clip.antiAlias,
          child: CustomPaint(painter: _GridPainter(), child: const Center(child: Icon(Icons.place, color: C.accent, size: 28))),
        ),
      );
}

class _PerfPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = C.line;
    for (double y = 6; y + 10 < size.height; y += 18) {
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(3, y, 8, 10), const Radius.circular(2)), p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

/// Кадр киноплёнки с фото находки.
class FilmFrame extends StatelessWidget {
  final String? photoPath;
  final Widget? badge;
  const FilmFrame({super.key, this.photoPath, this.badge});

  @override
  Widget build(BuildContext context) {
    final photo = photoPath != null
        ? Image.file(File(photoPath!), fit: BoxFit.cover)
        : Container(color: C.photo, child: const Icon(Icons.account_balance_wallet_outlined, size: 88, color: C.photoIcon));
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: Container(
        color: C.film,
        height: 330,
        child: Row(children: [
          SizedBox(width: 14, child: CustomPaint(painter: _PerfPainter(), size: const Size(14, 330))),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: Stack(fit: StackFit.expand, children: [
                  photo,
                  if (badge != null) Positioned(top: 10, left: 10, child: badge!),
                ]),
              ),
            ),
          ),
          SizedBox(width: 14, child: CustomPaint(painter: _PerfPainter(), size: const Size(14, 330))),
        ]),
      ),
    );
  }
}
