class FoundItem {
  final String id;
  final String? photoPath; // локальный путь; для сервера заменить на URL
  final double? lat;
  final double? lng;
  final String hiddenDetail; // скрытая примета, видна только нашедшему
  final DateTime createdAt;
  const FoundItem({
    required this.id,
    this.photoPath,
    this.lat,
    this.lng,
    this.hiddenDetail = '',
    required this.createdAt,
  });
}

class Claim {
  final String itemId;
  final String answer;
  const Claim({required this.itemId, required this.answer});
}
