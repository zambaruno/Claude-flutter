import 'package:flutter/material.dart';
import 'screens/feed_screen.dart';
import 'theme.dart';

void main() => runApp(const LostApp());

class LostApp extends StatelessWidget {
  const LostApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Lost',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const FeedScreen(),
      );
}
