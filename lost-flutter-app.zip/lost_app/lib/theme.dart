import 'package:flutter/material.dart';

class C {
  static const bg = Color(0xFF0F1B2D);
  static const card = Color(0xFF182840);
  static const line = Color(0xFF2A3E5E);
  static const text = Color(0xFFF4F6FA);
  static const muted = Color(0xFFA9B4C6);
  static const accent = Color(0xFFFFC93C);
  static const ink = Color(0xFF0F1B2D);
  static const photo = Color(0xFF22385A);
  static const photoIcon = Color(0xFF6C86AD);
  static const film = Color(0xFF05090F);
}

ThemeData buildTheme() => ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: C.bg,
      colorScheme: const ColorScheme.dark(primary: C.accent, onPrimary: C.ink, surface: C.bg),
    );
