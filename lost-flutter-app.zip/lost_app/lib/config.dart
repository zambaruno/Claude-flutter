import 'package:url_launcher/url_launcher.dart';

// TODO: заменить на свои адреса.
const kAppUrl = 'https://example.com/lost'; // постоянная страница со скачиванием APK (куда ведёт QR)
const kPaypalUrl = 'https://www.paypal.com/donate'; // TODO: своя ссылка PayPal
const kGooglePayUrl = 'https://example.com/donate'; // TODO: оплата через Google Pay (нужна интеграция)

Future<void> openLink(String url) async {
  await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
}
