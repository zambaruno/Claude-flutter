import 'package:flutter/foundation.dart';
import 'models.dart';

/// Состояние пользователя. TODO: заменить заглушки на реальный вход (Google/почта/телефон)
/// и реальную проверку личности (документ + селфи через сторонний сервис).
class AppState extends ChangeNotifier {
  bool signedIn = false;
  bool idVerified = false;
  void signIn() {
    signedIn = true;
    notifyListeners();
  }

  void verifyId() {
    idVerified = true;
    notifyListeners();
  }
}

final appState = AppState();

/// Слой данных. TODO: реализовать через сервер (Supabase/Firebase и т.п.).
abstract class LostRepository {
  ValueListenable<List<FoundItem>> get items;
  Future<void> addItem(FoundItem item);
  Future<void> submitClaim(Claim claim);
}

class MemoryRepository implements LostRepository {
  final ValueNotifier<List<FoundItem>> _items = ValueNotifier([
    FoundItem(id: '1', createdAt: DateTime.now().subtract(const Duration(hours: 2))),
    FoundItem(id: '2', createdAt: DateTime.now().subtract(const Duration(hours: 5))),
    FoundItem(id: '3', createdAt: DateTime.now().subtract(const Duration(days: 1))),
    FoundItem(id: '4', createdAt: DateTime.now().subtract(const Duration(days: 2))),
  ]);
  final List<Claim> claims = [];

  @override
  ValueListenable<List<FoundItem>> get items => _items;

  @override
  Future<void> addItem(FoundItem item) async {
    _items.value = [item, ..._items.value];
  }

  @override
  Future<void> submitClaim(Claim claim) async {
    claims.add(claim); // TODO: уведомить нашедшего, он сверяет ответ со скрытой приметой
  }
}

final LostRepository repo = MemoryRepository();
