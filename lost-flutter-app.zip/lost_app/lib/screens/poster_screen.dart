import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../config.dart';
import '../data/languages.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Экран 4. Плакат и 16 языков. Единственный экран с текстом (плюс обращение).
/// TODO: перевести обращение на все 16 языков, чтобы оно менялось вместе с языком плаката.
class PosterScreen extends StatefulWidget {
  const PosterScreen({super.key});

  @override
  State<PosterScreen> createState() => _PosterScreenState();
}

class _PosterScreenState extends State<PosterScreen> {
  int _sel = 0;
  final _key = GlobalKey();

  Future<void> _print() async {
    final boundary = _key.currentContext!.findRenderObject() as RenderRepaintBoundary;
    final img = await boundary.toImage(pixelRatio: 4); // картинкой, чтобы печатались любые алфавиты
    final data = await img.toByteData(format: ui.ImageByteFormat.png);
    final image = pw.MemoryImage(data!.buffer.asUint8List());
    final doc = pw.Document()..addPage(pw.Page(build: (_) => pw.Center(child: pw.Image(image))));
    await Printing.layoutPdf(onLayout: (_) => doc.save());
  }

  @override
  Widget build(BuildContext context) {
    final lang = kLangs[_sel];
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
          child: Column(children: [
            const Text(
              'Распечатайте этот плакат и повесьте там, где бывает много людей. Тот, кто нашёл вашу вещь и готов её вернуть, увидит его и найдёт вас.',
              style: TextStyle(fontSize: 16, height: 1.4, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 14),
            RepaintBoundary(
              key: _key,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
                child: Column(children: [
                  SizedBox(
                    height: 84,
                    child: Center(
                      child: Text(
                        lang.text,
                        textAlign: TextAlign.center,
                        textDirection: lang.rtl ? TextDirection.rtl : TextDirection.ltr,
                        style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, height: 1.15, color: Color(0xFF111111)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  QrImageView(data: kAppUrl, size: 150, backgroundColor: Colors.white),
                ]),
              ),
            ),
            const SizedBox(height: 14),
            GridView.count(
              crossAxisCount: 4,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              childAspectRatio: 1.85,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                for (var i = 0; i < kLangs.length; i++)
                  GestureDetector(
                    onTap: () => setState(() => _sel = i),
                    child: Container(
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: i == _sel ? C.accent : Colors.transparent,
                        border: Border.all(color: i == _sel ? C.accent : C.line, width: 2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(kLangs[i].name, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: i == _sel ? C.ink : C.text)),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            AccentButton(icon: Icons.print, label: 'Распечатать', onPressed: _print),
          ]),
        ),
      ),
    );
  }
}
