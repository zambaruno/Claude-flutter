import 'package:flutter/material.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Экран 3. Это моя вещь: строгая проверка личности (один раз), ответ про примету, заявка.
/// TODO: реальная проверка документа и селфи; уведомление нашедшему; передача вещи.
class ClaimScreen extends StatefulWidget {
  final FoundItem item;
  const ClaimScreen({super.key, required this.item});

  @override
  State<ClaimScreen> createState() => _ClaimScreenState();
}

class _ClaimScreenState extends State<ClaimScreen> {
  final _answer = TextEditingController();

  @override
  void dispose() {
    _answer.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    await repo.submitClaim(Claim(itemId: widget.item.id, answer: _answer.text));
    if (mounted) Navigator.pop(context);
  }

  Widget _stepBox(List<IconData> icons, {VoidCallback? onTap, bool done = false}) => GestureDetector(
        onTap: onTap,
        child: Container(
          height: 64,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            for (final i in icons) ...[Icon(i, color: C.accent, size: 26), const SizedBox(width: 10)],
            const Spacer(),
            if (done) const Icon(Icons.check, color: C.text, size: 26),
          ]),
        ),
      );

  Widget get _down => const Padding(padding: EdgeInsets.symmetric(vertical: 4), child: Icon(Icons.keyboard_arrow_down, color: C.muted));

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: appState,
        builder: (context, _) => Scaffold(
          appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0),
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
              child: Column(children: [
                Row(children: [
                  SizedBox(width: 64, height: 64, child: ClipRRect(borderRadius: BorderRadius.circular(10), child: FilmFrame(photoPath: widget.item.photoPath))),
                  const SizedBox(width: 12),
                  const Expanded(child: MiniMap(height: 64)),
                ]),
                const SizedBox(height: 16),
                // 1. Строгая проверка личности (документ + селфи). Заглушка: нажатие = проверено.
                _stepBox([Icons.badge, Icons.face], done: appState.idVerified, onTap: appState.idVerified ? null : appState.verifyId),
                _down,
                // 2. Доказать, что вещь ваша: ответить про скрытую примету.
                TextField(
                  controller: _answer,
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.help_outline, color: C.muted),
                    filled: true,
                    fillColor: C.card,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: C.line, width: 2)),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: C.line, width: 2)),
                  ),
                ),
                _down,
                // 3. Безопасная передача (информационный блок).
                _stepBox([Icons.swap_horiz, Icons.place]),
                const Spacer(),
                AccentButton(icon: Icons.check, label: 'Отправить заявку', onPressed: appState.idVerified ? _send : null),
              ]),
            ),
          ),
        ),
      );
}
