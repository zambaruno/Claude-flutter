import 'dart:io';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Экран 2. Я нашёл вещь: фото, геометка, скрытая примета, публикация.
class FoundScreen extends StatefulWidget {
  const FoundScreen({super.key});

  @override
  State<FoundScreen> createState() => _FoundScreenState();
}

class _FoundScreenState extends State<FoundScreen> {
  final _picker = ImagePicker();
  final _detail = TextEditingController();
  XFile? _photo;
  Position? _pos;

  @override
  void dispose() {
    _detail.dispose();
    super.dispose();
  }

  Future<void> _shoot() async {
    final shot = await _picker.pickImage(source: ImageSource.camera, imageQuality: 85);
    if (shot == null || !mounted) return;
    setState(() => _photo = shot);
    _locate();
  }

  Future<void> _locate() async {
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return;
      final p = await Geolocator.getCurrentPosition();
      if (!mounted) return;
      setState(() => _pos = p);
    } catch (_) {}
  }

  Future<void> _publish() async {
    await repo.addItem(FoundItem(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      photoPath: _photo?.path,
      lat: _pos?.latitude,
      lng: _pos?.longitude,
      hiddenDetail: _detail.text,
      createdAt: DateTime.now(),
    )); // TODO: отправить на сервер вместе с фото
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
            child: Column(children: [
              Container(
                height: 340,
                width: double.infinity,
                decoration: BoxDecoration(color: C.photo, borderRadius: BorderRadius.circular(20), border: Border.all(color: C.accent, width: 2)),
                clipBehavior: Clip.antiAlias,
                child: _photo == null
                    ? const Icon(Icons.photo_camera, size: 72, color: C.photoIcon)
                    : Image.file(File(_photo!.path), fit: BoxFit.cover),
              ),
              const SizedBox(height: 16),
              Semantics(
                button: true,
                label: 'Сделать снимок',
                child: GestureDetector(
                  onTap: _shoot,
                  child: Container(
                    width: 76,
                    height: 76,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: C.text, border: Border.all(color: C.accent, width: 4)),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(children: [
                const Expanded(child: MiniMap(height: 52)),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _detail,
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.visibility_off, color: C.muted),
                      filled: true,
                      fillColor: C.card,
                      contentPadding: const EdgeInsets.symmetric(vertical: 14),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: C.line, width: 2)),
                      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: C.line, width: 2)),
                    ),
                  ),
                ),
              ]),
              const Spacer(),
              AccentButton(icon: Icons.check, label: 'Опубликовать', onPressed: _photo == null ? null : _publish),
            ]),
          ),
        ),
      );
}
