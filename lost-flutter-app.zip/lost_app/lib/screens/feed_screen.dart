import 'package:flutter/material.dart';
import '../config.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'claim_screen.dart';
import 'donate_screen.dart';
import 'found_screen.dart';
import 'login_screen.dart';
import 'poster_screen.dart';

/// Экран 1. Лента находок: плёнка, реклама после каждых 3 кадров, донаты в шапке.
class FeedScreen extends StatelessWidget {
  const FeedScreen({super.key});

  void _go(BuildContext context, Widget screen) => Navigator.push(context, MaterialPageRoute(builder: (_) => screen));

  /// Если не вошёл, сначала экран входа. Возвращает true, если можно продолжать.
  static Future<bool> ensureSignedIn(BuildContext context) async {
    if (appState.signedIn) return true;
    final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    return ok == true;
  }

  Future<void> _onFound(BuildContext context) async {
    if (!await ensureSignedIn(context)) return;
    if (!context.mounted) return;
    _go(context, const FoundScreen());
  }

  Future<void> _onMine(BuildContext context, FoundItem item) async {
    if (!await ensureSignedIn(context)) return;
    if (!context.mounted) return;
    _go(context, ClaimScreen(item: item));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
            child: Row(children: [
              const Icon(Icons.search, color: C.accent, size: 34),
              const Spacer(),
              OutlineIconButton(icon: Icons.print, label: 'Плакат', onPressed: () => _go(context, const PosterScreen())),
              const SizedBox(width: 10),
              OutlineIconButton(icon: Icons.attach_money, label: 'Поддержать проект', onPressed: () => _go(context, const DonateScreen())),
              const SizedBox(width: 10),
              OutlineIconButton(icon: Icons.credit_card, label: 'PayPal', onPressed: () => openLink(kPaypalUrl)),
              const SizedBox(width: 10),
              OutlineIconButton(icon: Icons.account_balance_wallet_outlined, label: 'Google Pay', onPressed: () => openLink(kGooglePayUrl)),
            ]),
          ),
          Expanded(
            child: ValueListenableBuilder<List<FoundItem>>(
              valueListenable: repo.items,
              builder: (context, items, _) {
                final rows = <Widget>[];
                for (var i = 0; i < items.length; i++) {
                  rows.add(_ItemCard(item: items[i], onMine: () => _onMine(context, items[i])));
                  if ((i + 1) % 3 == 0) rows.add(const _AdSlot()); // реклама после каждых 3 кадров
                }
                return ListView(padding: const EdgeInsets.symmetric(horizontal: 20), children: rows);
              },
            ),
          ),
          Container(
            height: 76,
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: C.line))),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
              const SizedBox(width: 56, child: Icon(Icons.theaters, color: C.accent, size: 28)),
              SizedBox(
                width: 68,
                height: 68,
                child: Semantics(
                  button: true,
                  label: 'Сфотографировать находку',
                  child: ElevatedButton(
                    onPressed: () => _onFound(context),
                    style: ElevatedButton.styleFrom(backgroundColor: C.accent, foregroundColor: C.ink, shape: const CircleBorder(), padding: EdgeInsets.zero),
                    child: const Icon(Icons.photo_camera, size: 32),
                  ),
                ),
              ),
              const SizedBox(width: 56, child: Icon(Icons.place, color: C.muted, size: 28)), // TODO: экран карты
            ]),
          ),
        ]),
      ),
    );
  }
}

class _ItemCard extends StatelessWidget {
  final FoundItem item;
  final VoidCallback onMine;
  const _ItemCard({required this.item, required this.onMine});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: Column(children: [
          FilmFrame(
            photoPath: item.photoPath,
            badge: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: C.accent, borderRadius: BorderRadius.circular(20)),
              child: const Icon(Icons.schedule, size: 18, color: C.ink),
            ),
          ),
          const SizedBox(height: 14),
          Row(children: [
            const Expanded(child: MiniMap()),
            const SizedBox(width: 10),
            Expanded(child: AccentButton(icon: Icons.sentiment_very_satisfied, label: 'Это моя вещь', height: 56, onPressed: onMine)),
          ]),
        ]),
      );
}

class _AdSlot extends StatelessWidget {
  const _AdSlot();

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 16),
        height: 60,
        decoration: BoxDecoration(border: Border.all(color: C.line, width: 2), borderRadius: BorderRadius.circular(14)),
        child: const Center(child: Icon(Icons.campaign, color: C.muted, size: 28)), // TODO: подключить рекламную сеть
      );
}
