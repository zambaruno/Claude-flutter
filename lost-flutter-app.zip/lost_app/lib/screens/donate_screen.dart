import 'package:flutter/material.dart';
import '../config.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Экран 6. Донаты: три суммы, PayPal, Google Pay.
/// TODO: передавать выбранную сумму в платёж; для Google Pay нужна интеграция.
class DonateScreen extends StatefulWidget {
  const DonateScreen({super.key});

  @override
  State<DonateScreen> createState() => _DonateScreenState();
}

class _DonateScreenState extends State<DonateScreen> {
  int _sel = 1;

  Widget _amount(int i, double size) {
    final on = _sel == i;
    return Expanded(
      child: Semantics(
        button: true,
        label: 'Сумма',
        child: SizedBox(
          height: 84,
          child: ElevatedButton(
            onPressed: () => setState(() => _sel = i),
            style: ElevatedButton.styleFrom(
              backgroundColor: on ? C.accent : Colors.transparent,
              foregroundColor: on ? C.ink : C.accent,
              elevation: 0,
              side: on ? null : const BorderSide(color: C.line, width: 2),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: Icon(Icons.monetization_on_outlined, size: size),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
            child: Column(children: [
              const SizedBox(height: 24),
              Container(
                width: 140,
                height: 140,
                decoration: const BoxDecoration(color: C.card, shape: BoxShape.circle),
                child: const Icon(Icons.attach_money, color: C.accent, size: 76),
              ),
              const SizedBox(height: 32),
              Row(children: [_amount(0, 28), const SizedBox(width: 12), _amount(1, 40), const SizedBox(width: 12), _amount(2, 54)]),
              const SizedBox(height: 20),
              WideButton(icon: Icons.credit_card, label: 'Поддержать через PayPal', background: const Color(0xFF0070BA), foreground: Colors.white, onPressed: () => openLink(kPaypalUrl)),
              const SizedBox(height: 14),
              WideButton(icon: Icons.account_balance_wallet_outlined, label: 'Поддержать через Google Pay', background: Colors.white, foreground: C.ink, onPressed: () => openLink(kGooglePayUrl)),
              const Spacer(),
              const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.attach_money, color: C.accent, size: 30),
                SizedBox(width: 14),
                Icon(Icons.swap_horiz, color: C.muted, size: 26),
                SizedBox(width: 14),
                Icon(Icons.sentiment_very_satisfied, color: C.accent, size: 36),
              ]),
            ]),
          ),
        ),
      );
}
