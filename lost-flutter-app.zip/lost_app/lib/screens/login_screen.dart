import 'package:flutter/material.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Экран 5. Вход: Google, почта, телефон. Нашедшему достаточно обычной регистрации.
/// TODO: подключить реальные способы входа (google_sign_in, почта, SMS).
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _picked = false;

  void _pick() => setState(() => _picked = true); // заглушка: любой способ считается выбранным

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
            child: Column(children: [
              const SizedBox(height: 24),
              const Icon(Icons.search, color: C.accent, size: 88),
              const SizedBox(height: 48),
              WideButton(icon: Icons.account_circle, label: 'Войти через Google', background: Colors.white, foreground: C.ink, onPressed: _pick),
              const SizedBox(height: 14),
              WideButton(icon: Icons.mail_outline, label: 'Войти по электронной почте', onPressed: _pick),
              const SizedBox(height: 14),
              WideButton(icon: Icons.smartphone, label: 'Войти по номеру телефона', onPressed: _pick),
              const Spacer(),
              AccentButton(
                icon: Icons.check,
                label: 'Продолжить',
                onPressed: _picked
                    ? () {
                        appState.signIn();
                        Navigator.pop(context, true);
                      }
                    : null,
              ),
            ]),
          ),
        ),
      );
}
